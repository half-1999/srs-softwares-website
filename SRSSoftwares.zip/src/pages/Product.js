import React from 'react';

const Product = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold">Product</h1>
      <p>This is the Product page.</p>
    </div>
  );
};

export default Product;
