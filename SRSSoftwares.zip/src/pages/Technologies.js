import React from 'react';
import { FaNodeJs, FaPhp, FaAngular, FaReact, FaVuejs, FaDatabase, FaMobileAlt, FaAndroid, FaJs, FaCloud, FaLaptopCode, FaTools, FaAws } from 'react-icons/fa';
import { SiPostgresql, SiMysql, SiTailwindcss, SiMicrosoftsqlserver, SiMicrosoftazure, SiGooglecloud } from 'react-icons/si';
import { IoLogoPython } from 'react-icons/io';
import TechImg from '../assets/technologies.jpg';
import NextJsIcon from '../utils/NextJsIcon';
import DotNetIcon from '../utils/DotNetIcon';
import FirebaseIcon from '../utils/FirebaseIcon';
import Banner from '../components/Banner';
import { DiDotnet, DiFirebase, DiMongodb, DiMsqlServer } from 'react-icons/di';

const techData = {
  backend: [
    {
      name: '.Net',
      icon: <DiDotnet size={48} />,
      color: 'text-red-600',
      content: 'Java is a versatile and widely-used programming language. Ideal for building robust and scalable applications.',
    },
    {
      name: 'Node.js',
      icon: <FaNodeJs size={48} />,
      color: 'text-green-600',
      content: 'Node.js is a JavaScript runtime built on Chrome\'s V8 engine. Perfect for building fast and scalable network applications.',
    },
    {
      name: 'PHP',
      icon: <FaPhp size={48} />,
      color: 'text-purple-600',
      content: 'PHP is a popular scripting language for web development. It powers many websites and applications.',
    },
    {
      name: 'Python',
      icon: <IoLogoPython size={48} />,
      color: 'text-yellow-500',
      content: 'Python is a high-level, interpreted language known for its readability and broad applicability in data analysis, AI, and web development.',
    },

  ],
  frontend: [
    {
      name: 'JavaScript',
      icon: <FaJs size={48} />,
      color: 'text-yellow-500',
      content: 'JavaScript is a versatile programming language used for creating interactive and dynamic web applications. It enables developers to build client-side and server-side code with a single language.',
    },
    {
      name: 'ReactJS',
      icon: <FaReact size={48} />,
      color: 'text-blue-600',
      content: 'ReactJS is a JavaScript library for building user interfaces. It allows developers to create single-page applications with a responsive design.',
    },
    {
      name: 'React Native',
      icon: <FaMobileAlt size={48} />,
      color: 'text-blue-600',
      content: 'React Native is a framework for building native applications using React. It allows developers to create applications for iOS and Android using JavaScript and React.',
    },
    {
      name: 'AngularJS',
      icon: <FaAngular size={48} />,
      color: 'text-red-600',
      content: 'AngularJS is a structural framework for dynamic web apps. It extends HTML with custom attributes and binds data to HTML with expressions.',
    },
    {
      name: 'VueJS',
      icon: <FaVuejs size={48} />,
      color: 'text-green-600',
      content: 'VueJS is a progressive framework for building user interfaces. It is designed to be incrementally adoptable.',
    },
    {
      name: 'Tailwind CSS',
      icon: <SiTailwindcss size={48} />,
      color: 'text-blue-500',
      content: 'Tailwind CSS is a utility-first CSS framework for creating custom designs without leaving your HTML. It provides low-level utility classes for rapid UI development.',
    },
    {
      name: 'Next.js',
      icon: <NextJsIcon size={48} />,
      color: 'text-gray-800',
      content: 'Next.js is a React framework for server-side rendering and static site generation. It simplifies the process of building and deploying React applications.',
    },
    // {
    //   name: 'Framer Motion',
    //   icon: <motion.div className="text-red-600" />,
    //   color: 'text-red-600',
    //   content: 'Framer Motion is a library for animations and interactions in React. It provides a simple and powerful API for creating complex animations with ease.',
    // },
  ],
  database: [
    {
      name: 'MSSQL',
      icon: <DiMsqlServer size={48} />,
      color: 'text-yellow-700',
      content: 'MSSQL is a relational database management system developed by Microsoft. It is known for its integration with other Microsoft services and strong performance.',
    },
    {
      name: 'MongoDB',
      icon: <DiMongodb size={48} color='green'/>,
      color: 'text-gray-600',
      content: 'MongoDB is a NoSQL database known for its high performance and scalability. It stores data in a flexible, JSON-like format.',
    },
    {
      name: 'MySQL',
      icon: <SiMysql size={48} />,
      color: 'text-blue-500',
      content: 'MySQL is a widely used open-source relational database management system. It is known for its reliability and ease of use.',
    },
    {
      name: 'PostgreSQL',
      icon: <SiPostgresql size={48} />,
      color: 'text-blue-800',
      content: 'PostgreSQL is a powerful, open-source object-relational database system. Known for its robustness and flexibility.',
    },
    {
      name: 'Firebase',
      icon: <DiFirebase size={48} />,
      color: 'text-red-600',
      content: 'Firebase is a platform developed by Google for creating mobile and web applications. It offers a real-time NoSQL database and other backend services.',
    },
  ],
  mobile: [
    
    {
      name: 'Android',
      icon: <FaAndroid size={48} />,
      color: 'text-green-600',
      content: 'Android is a mobile operating system developed by Google. It is used in a wide range of devices and offers extensive customization.',
    },
    {
      name: 'Flutter',
      icon: <FaMobileAlt size={48} />,
      color: 'text-blue-400',
      content: 'Flutter is an open-source UI software development kit created by Google. It allows for building natively compiled applications for mobile, web, and desktop from a single codebase.',
    },
    {
      name: 'React Native',
      icon: <FaReact size={48} />,
      color: 'text-gray-600',
      content: 'React Native is a framework for building native applications using React. It allows you to write native code for iOS and Android using JavaScript.',
    },
    
  ],
  cloud: [
    {
      name: 'AWS',
      icon: <FaAws size={48} />,
      color: 'text-yellow-500',
      content: 'AWS (Amazon Web Services) is a comprehensive cloud computing platform offering a wide range of services, including storage, networking, and AI.',
    },
    {
      name: 'Google Cloud',
      icon: <SiGooglecloud size={48} />,
      color: 'text-blue-600',
      content: 'Google Cloud provides a suite of cloud computing services that runs on the same infrastructure that Google uses for its end-user products.',
    },
    {
      name: 'Azure',
      icon: <SiMicrosoftazure size={48} />,
      color: 'text-blue-700',
      content: 'Azure is Microsoft\'s cloud computing platform, offering solutions for building, testing, deploying, and managing applications and services.',
    },
  ],
  qa: [
    {
      name: 'Manual QA Testing',
      icon: <FaTools size={48} />,
      color: 'text-gray-600',
      content: 'Manual QA Testing involves human testers manually executing test cases without the use of automation tools.',
    },
    {
      name: 'Web Testing Automation',
      icon: <FaLaptopCode size={48} />,
      color: 'text-blue-500',
      content: 'Web Testing Automation uses software tools to execute pre-scripted tests on web applications, ensuring they function correctly.',
    },
    {
      name: 'Mobile App Testing',
      icon: <FaMobileAlt size={48} />,
      color: 'text-green-600',
      content: 'Mobile App Testing involves testing mobile applications for functionality, usability, and consistency across different devices and operating systems.',
    },
    {
      name: 'API Testing',
      icon: <FaCloud size={48} />,
      color: 'text-red-600',
      content: 'API Testing involves testing APIs directly and as part of integration testing to determine if they meet expectations for functionality, reliability, performance, and security.',
    },
  ],
};

const Technologies = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Background Image */}
      <Banner
        image={TechImg}
        heading="Technologies"
        paragraph="Innovative software solutions for digital disruption."
      />

      {/* Technologies Content */}
      <div className="container mx-auto p-2">
        <div className="text-center px-4 py-2">
          <h1 className="text-lg lg:text-2xl font-bold mb-2">Our Working Technologies</h1>
          <p className="text-sm lg:text-md">Designing and developing innovative and professional software solutions for many companies and tech markets for almost two decades now.</p>
        </div>
        
        {/* Frontend Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
        <h2 className="text-lg font-bold mb-4 ">Frontend Technologies</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-2 bg-gray-100 p-2 rounded-lg ">
            {techData.frontend.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl cursor-pointer overflow-hidden flex flex-col items-center hover:scale-95 duration-700">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-sm text-justify">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Backend Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
          <h2 className="text-lg font-bold mb-1 ">Backend Technologies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 bg-gray-100 p-2 rounded-lg">
            {techData.backend.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl cursor-pointer overflow-hidden flex flex-col items-center hover:scale-95 duration-700">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-sm text-justify">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>

        

        {/* Database Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
          <h2 className="text-lg font-bold mb-4 ">Database Technologies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 bg-gray-100 gap-2 p-2 rounded-lg ">
            {techData.database.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl cursor-pointer overflow-hidden flex flex-col items-center hover:scale-95 duration-700">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-sm text-justify">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
          <h2 className="text-lg font-bold mb-4 ">Mobile Technologies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3  gap-2 bg-gray-100 p-2 rounded-lg">
            {techData.mobile.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl overflow-hidden flex flex-col items-center hover:scale-95 duration-700 cursor-pointer">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-justify text-sm">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>


        {/* Cloud Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
          <h2 className="text-lg font-bold mb-4">Cloud Technologies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-2 bg-gray-100 p-2 rounded-lg">
            {techData.cloud.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl overflow-hidden flex flex-col items-center hover:scale-95 duration-700 cursor-pointer">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-sm text-justify">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quality Assurance Section */}
        <div className="mb-2 mx-auto p-3 rounded-lg">
          <h2 className="text-lg font-bold mb-4">Quality Assurance</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-2 bg-gray-100 p-2 rounded-lg">
            {techData.qa.map((tech, index) => (
              <div key={index} className="relative group bg-white p-4 rounded-lg shadow-md hover:shadow-xl overflow-hidden flex flex-col items-center hover:scale-95 duration-700 cursor-pointer">
                <div className="flex justify-center items-center mb-4">
                  <div className={`text-6xl ${tech.color}`}>
                    {tech.icon}
                  </div>
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <hr className="border-t-1 border-black" />
                  <p className="text-sm text-justify">{tech.content}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Technologies;
