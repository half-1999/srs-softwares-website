import React from 'react';

const ContactUs = () => {
  return (
    <div className="container mx-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Left Side - Text */}
      <div className="space-y-1 my-auto">
        <h1 className="text-xl font-bold">Contact Us</h1>
        <h1 className="text-3xl font-bold mb-4">Struggling with IT Challenges? Get Expert Help Now!</h1>
        <p>
          Are you grappling with IT problems that seem too complex or time-consuming to resolve on your own? Let us help! We understand that technology issues can be overwhelming, and we're here to offer a helping hand. Our free IT consultation service is designed to give you the clarity and guidance you need without any obligation.
        </p>
        <p>
          During your free consultation, you'll benefit from:
        </p>
        <ul className="list-disc pl-5">
          <li>A straightforward conversation: We listen to your concerns and provide clear, jargon-free advice tailored to your situation.</li>
          <li>Expert analysis: Our team will investigate the root cause of your IT problems, whether they involve slow systems, software issues, or security concerns.</li>
          <li>Customized solutions: We offer recommendations that fit your specific needs and budget, avoiding generic fixes.</li>
          <li>Valuable insights: Even if you choose not to work with us, you'll receive actionable advice to help you move forward with confidence.</li>
        </ul>
        <p className="font-bold">Contact Details:</p>
        <p>Email: <a href="mailto:info.srssoftwares.com" className="text-blue-500">info.srssoftwares.com</a></p>
        <p>Phone 1: <a href="tel:+918869829800" className="text-blue-500">+91 886 982 9800</a></p>
        <p>Phone 2: <a href="tel:+919557775740" className="text-blue-500">+91 955 777 5740</a></p>
        <p>Address: C-815 , iThum Tower Block-A, Sector 65, Noida, Uttar Pradesh 201301</p>
      </div>

      {/* Right Side - Form */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-bold mb-4">Request Your Free IT Consultation</h2>
        <form>
          <div className="mb-4">
            <label htmlFor="firstName" className="block text-sm font-medium mb-2">First Name *</label>
            <input type="text" id="firstName" name="firstName" required className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
          <div className="mb-4">
            <label htmlFor="lastName" className="block text-sm font-medium mb-2">Last Name *</label>
            <input type="text" id="lastName" name="lastName" required className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
          <div className="mb-4">
            <label htmlFor="phone" className="block text-sm font-medium mb-2">Phone *</label>
            <input type="tel" id="phone" name="phone" required className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block text-sm font-medium mb-2">Company Email *</label>
            <input type="email" id="email" name="email" required className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
          <div className="mb-4">
            <label htmlFor="company" className="block text-sm font-medium mb-2">Company/Organization *</label>
            <input type="text" id="company" name="company" required className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
          <div className="mb-4">
            <label htmlFor="message" className="block text-sm font-medium mb-2">How can we assist you? *</label>
            <select id="message" name="message" required className="w-full p-2 border border-gray-300 rounded-md">
              <option value="">Select a service</option>
              <option value="enterpriseSolutions">Enterprise Solutions</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="mb-4">
            <label htmlFor="details" className="block text-sm font-medium mb-2">Your message</label>
            <textarea id="details" name="details" className="w-full p-2 border border-gray-300 rounded-md" rows="4"></textarea>
          </div>
          <button type="submit" className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default ContactUs;
