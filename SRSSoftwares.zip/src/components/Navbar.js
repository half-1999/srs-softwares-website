import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FaBars, FaTimes, FaChevronDown, FaChevronUp } from 'react-icons/fa'; // Add icons for dropdown
import { services } from '../utils/data';

const Navbar = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const handleMobileMenuToggle = () => {
    setMobileMenuOpen(prev => !prev);
    if (mobileMenuOpen) {
      setDropdownOpen(false);
    }
  };

  const handleDropdownToggle = () => {
    setDropdownOpen(prev => !prev);
  };

  const handleScroll = () => {
    setScrolled(window.scrollY > 250);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-transform duration-300 ease-in-out  ${scrolled ? 'bg-white w-full top-0 shadow-lg' : 'bg-white w-[90%] top-2 shadow-xl mx-auto rounded-lg'}`}
      style={{ transition: 'all 0.3s ease-in-out' }}
    >
      <div className="container mx-auto flex justify-between items-center p-4">
        <Link to="/" className="font-bold">
          <img src='https://www.srssoftwares.in/assets/images/logo/ptac.png' alt="Service" className="rounded-xl w-[100px]" />
        </Link>
        <div className="hidden md:flex space-x-4">
          <ul className="flex space-x-4 text-md font-bold">
            <li className='mt-2'><Link to="/about">Company</Link></li>
            <li className="relative mt-2">
              <div 
                className="cursor-pointer flex items-center"
                onMouseEnter={() => setDropdownOpen(true)}
                onMouseLeave={() => setDropdownOpen(false)}
              >
                Services
                <motion.div
                  initial={{ rotate: 0 }}
                  animate={{ rotate: dropdownOpen ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                  className="ml-2"
                >
                  {dropdownOpen ? <FaChevronUp /> : <FaChevronDown />}
                </motion.div>
                <AnimatePresence>
                  {dropdownOpen && (
                    <motion.ul
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute left-0 mt-[525%] w-64 bg-black text-white shadow-lg z-50 grid grid-cols-1 gap-2"
                    >
                      {services.map((service, index) => (
                        <li key={index} className="px-2 py-1 hover:bg-cyan-200 text-sm border-b">
                          <Link to={`/services/${service.route}`}>{service.name}</Link>
                        </li>
                      ))}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </div>
            </li>
            <li className='mt-2'><Link to="/technologies">Technologies</Link></li>
            <li className='border p-2 bg-gray-200 rounded-lg'><Link to="/contact">Let's Connect</Link></li>
          </ul>
        </div>
        {/* Mobile Menu Icon */}
        <div className="md:hidden flex items-center">
          <button onClick={handleMobileMenuToggle}><FaBars size={24} /></button>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300 }}
            className="fixed top-0 right-0 h-full w-64 bg-gray-800 text-white shadow-lg z-50 overflow-y-auto"
          >
            <div className="flex justify-end p-4">
              <button onClick={handleMobileMenuToggle}><FaTimes size={24} /></button>
            </div>
            <ul className="mt-8">
              <li><Link to="/" onClick={handleMobileMenuToggle} className="flex items-center px-4 py-2 border-b border-gray-700 text-sm">Home</Link></li>
              <li><Link to="/technologies" onClick={handleMobileMenuToggle} className="flex items-center px-4 py-2 border-b border-gray-700 text-sm">Technologies</Link></li>
              <li><Link to="/about" onClick={handleMobileMenuToggle} className="flex items-center px-4 py-2 border-b border-gray-700 text-sm">About</Link></li>
              <li><Link to="/contact" onClick={handleMobileMenuToggle} className="flex items-center px-4 py-2 border-b border-gray-700 text-sm">Contact</Link></li>
              <li className="relative">
                <div 
                  className="cursor-pointer px-4 py-2 border-t border-gray-700 text-sm flex items-center"
                  onClick={handleDropdownToggle}
                >
                  Services
                  <motion.div
                    initial={{ rotate: 0 }}
                    animate={{ rotate: dropdownOpen ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                    className="ml-2"
                  >
                    {dropdownOpen ? <FaChevronUp /> : <FaChevronDown />}
                  </motion.div>
                </div>
                <AnimatePresence>
                  {dropdownOpen && (
                    <motion.ul
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute left-0 mt-2 w-full bg-gray-800 text-white shadow-lg"
                    >
                      {services.map((service, index) => (
                        <li key={index} className="px-4 py-2 hover:bg-gray-700 text-sm">
                          <Link 
                            to={`/services/${service.route}`} 
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            {service.name}
                          </Link>
                        </li>
                      ))}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
