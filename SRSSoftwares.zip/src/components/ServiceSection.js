import React from 'react';

const ServiceSection = ({ imagePath, content, type }) => {
  return (
    <div className={`flex ${type === 'left' ? 'flex-row' : 'flex-row-reverse'} items-center my-8`}>
      <div className="w-1/2">
        <img src={imagePath} alt="Service" className="w-full h-auto" />
      </div>
      <div className="w-1/2 p-4">
        <p>{content}</p>
      </div>
    </div>
  );
};

export default ServiceSection;
