import React from 'react';
import { Link } from 'react-router-dom';
import { FaAddressCard, FaWhatsapp } from 'react-icons/fa';
import { services } from '../utils/data';
import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram, FaGithub } from 'react-icons/fa';
import { IoIosMail } from 'react-icons/io';
import { MdOutlinePhoneCallback } from 'react-icons/md';

const Footer = () => {
  return (
    <footer className="py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between space-y-6 md:space-y-0">
          {/* Company Info */}
          <div className="flex-1 flex items-center justify-center border-r border-black mr-2">
            <div className="flex-1 my-auto p-6">
              <div className="flex justify-center mb-4 rounded-xl">
                <img src="https://www.srssoftwares.in/assets/images/logo/ptac.png" alt="" className="w-[200px]  object-contain rounded-full mx-auto"/>
              </div>
              <h3 className="text-2xl font-bold text-center">SRS SOFTWRES </h3>
            <p className="text-md mb-4 text-justify">
              We are a leading technology company specializing in the development of enterprise-level solutions.
            </p>
            <p className="text-md mb-4 font-semibold">
              Mon - Sat: 09:00 PM - 09:00 PM
            </p>
            <p className='flex gap-2'><IoIosMail size={25}/> <a href="mailto:info.srssoftwares.com" className="text-blue-500">info.srssoftwares.com</a></p>
            <p className='flex gap-2'><MdOutlinePhoneCallback size={25}/><a href="tel:+918869829800" className="text-blue-500">+91 886 982 9800</a></p>
            <p className='flex gap-2'><MdOutlinePhoneCallback size={25}/><a href="tel:+919557775740" className="text-blue-500">+91 955 777 5740</a></p>
              <p className='flex gap-2'><FaAddressCard size={25} /> 
              <span className="text-blue-500 ml-2">C-815 , iThum Tower Block-A, Sector 65, Noida, Uttar Pradesh 201301</span>
              </p>    

            </div>
          </div>

          {/* Company */}
          <div className="flex-1 border-r border-black mr-2">
            <h3 className="text-lg font-bold mb-4">Company</h3>
            <ul className="space-y-2 text-sm font-semibold">
              <li><Link to="/about">About</Link></li>
              <li><Link to="/product">Products</Link></li>
              <li><Link to="/technologies">Technologies</Link></li>
              <li><Link to="/contact">Let's Connect</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div className="flex-1 border-r border-black mr-2">
            <h3 className="text-lg font-bold mb-4">Explore our Services</h3>
            {services.map((service, index) => (
          <div key={index} className="text-sm">
          <Link to={`/services/${service.route}`}>
            <h2 className="text-sm font-semibold cursor-pointer mb-2">{service.name}</h2>
            </Link>
          </div>
        ))}
          </div>

          

          {/* Contact */}
          <div className="flex-1 flex items-center justify-center">
            <div className="flex-1 my-auto p-6">
          <h3 className="text-lg font-bold mb-4">Connect on Social Media</h3>
          <p className="text-sm mb-4">
            Say goodbye to emails! Streamline communication and get the answers you need without the wait. Get started to initiate a chat with your Business Analyst now.
          </p>
          <a href="https://wa.me/+91-9557775740" className="flex items-center space-x-2 text-sm text-black font-bold hover:underline mb-4" target="_blank" rel="noopener noreferrer">
            <FaWhatsapp className="text-xl" />
            <span>Connect on WhatsApp</span>
          </a>
          <div className="flex space-x-4">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">
              <FaFacebookF className="text-2xl" />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-600">
              <FaTwitter className="text-2xl" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-blue-700 hover:text-blue-900">
              <FaLinkedinIn className="text-2xl" />
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-pink-600 hover:text-pink-800">
              <FaInstagram className="text-2xl" />
            </a>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-800 hover:text-gray-600">
              <FaGithub className="text-2xl" />
            </a>
          </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
