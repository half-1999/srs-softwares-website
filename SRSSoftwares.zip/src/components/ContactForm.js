import React from 'react';
import { FaUser, FaEnvelope, FaPhoneAlt, FaBuilding, FaClipboard } from 'react-icons/fa';

const ContactForm = () => {
  const handleSubmit = (event) => {
    event.preventDefault();
    
    // Create a FormData object from the form element
    const formData = new FormData(event.target);

    // Convert FormData to a plain object
    const data = {};
    formData.forEach((value, key) => {
      data[key] = value;
    });

    // Log the form data to the console
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-6 mb-4 space-y-4">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
          <FaUser className="text-blue-500 text-xl mr-2" />
          Name
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          id="name"
          name="name"
          type="text"
          placeholder="Your name"
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
            <FaEnvelope className="text-blue-500 text-xl mr-2" />
            Email
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
            id="email"
            name="email"
            type="email"
            placeholder="Your email address"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
            <FaPhoneAlt className="text-blue-500 text-xl mr-2" />
            Contact Number
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
            id="contact"
            name="contact"
            type="text"
            placeholder="Your contact number"
            required
          />
        </div>
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
          <FaBuilding className="text-blue-500 text-xl mr-2" />
          Company Name
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          id="company"
          name="company"
          type="text"
          placeholder="Your company name"
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
          <FaClipboard className="text-blue-500 text-xl mr-2" />
          Service
        </label>
        <select
          className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          id="service"
          name="service"
          required
        >
          <option value="">Select a service</option>
          <option value="Software Development">Software Development</option>
          <option value="Web Development">Web Development</option>
          <option value="Development Team">Development Team</option>
          <option value="Product Development">Product Development</option>
          <option value="E-Commerce">E-Commerce</option>
          <option value="Mobile Apps">Mobile Apps</option>
          <option value="Testing & QA">Testing & QA</option>
          <option value="UI/UX Design">UI/UX Design</option>
        </select>
      </div>
      <div className="mb-6">
        <label className="block text-gray-700 text-sm font-semibold mb-2 flex items-center">
          <FaClipboard className="text-blue-500 text-xl mr-2" />
          Message
        </label>
        <textarea
          className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500"
          id="message"
          name="message"
          rows="4"
          placeholder="Your message"
          required
        />
      </div>
      <div className="flex items-center justify-end">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded focus:outline-none focus:shadow-outline"
          type="submit"
        >
          Send Message
        </button>
      </div>
    </form>
  );
};

export default ContactForm;
