import { FaReact, FaNodeJs, FaCss3, FaHtml5, FaJava, FaPython, FaJs, FaLightbulb, FaShieldAlt, FaHandsHelping, FaThumbsUp, FaShoppingCart, FaMobileAlt, FaPalette, FaDatabase, FaCloud, FaRobot, FaChartLine, FaNetworkWired, FaTools, FaCode, FaCube, FaCog, FaNewspaper, FaShoppingBag, FaPhone, FaFilm, FaBuilding, FaTruck, FaHospital, FaGraduationCap, FaDollarSign, FaChessBoard, FaCogs, FaRocket, FaEye, FaHandHoldingHeart, FaUserAlt, FaProjectDiagram, FaMapMarkerAlt, FaWrench, FaEnvelope, FaFileAlt, FaShareAlt, FaSearch, FaLock, FaTachometerAlt, FaUserShield, FaUserCog, FaPlug, FaPaintBrush, FaWarehouse, FaCreditCard, FaCloudUploadAlt, FaSyncAlt } from 'react-icons/fa';
import { SiTailwindcss, SiMongodb, SiExpress } from 'react-icons/si';
import { FaCheckCircle, FaUsers, FaHandshake } from 'react-icons/fa';
import { FaBullseye } from 'react-icons/fa';
import { FaLaptop, FaLaptopCode } from 'react-icons/fa6';

export const services = [
  {
    name: 'Custom Software Development',
    route: 'custom-software-development',
    description: 'Do you need a custom software solution that meets your specific business needs? We design and develop bespoke software tailored to your requirements.',
    icon: <FaCog  className="text-3xl mx-auto mb-2 text-blue-500" />
  },
  {
    name: 'Website Designing',
    route: 'website-designing',
    description: 'Enhance your online presence with our professional website designing services. We create visually appealing and user-friendly websites that capture your brand’s essence.',
    icon: <FaLaptop className="text-3xl mx-auto mb-2 text-red-500" />
  },
  {
    name: 'Web Development',
    route: 'web-development',
    description: 'Our web developers improve your website\'s frontend and backend by using the latest web development technology stack. Shape your brand personality with responsive web designs and libraries.',
    icon: <FaLaptopCode className="text-3xl mx-auto mb-2 text-red-500" />
  },
  {
    name: 'IT Consulting',
    route: 'it-consulting',
    description: 'Receive expert advice on IT strategy, infrastructure, and management. Our IT consulting services are designed to help you make informed decisions and optimize your technology investments.',
    icon: <FaUsers className="text-3xl mx-auto mb-2 text-blue-500" />
  },
  
  {
    name: 'Digital Marketing',
    route: 'digital-marketing',
    description: 'Grow your online presence with targeted digital marketing strategies. We offer SEO, PPC, content marketing, and social media management to boost your brand visibility and drive traffic.',
    icon: <FaBullseye className="text-3xl mx-auto mb-2 text-red-500" />
  },
  {
    name: 'Search Engine Optimization',
    route: 'search-engine-optimization',
    description: 'Improve your website’s ranking on search engines with our SEO services. We optimize your site’s content, structure, and performance to enhance visibility and attract more organic traffic.',
    icon: <FaChartLine className="text-3xl mx-auto mb-2 text-red-500" />
  },
  {
    name: 'Ecommerce Development',
    route: 'ecommerce-development',
    description: 'Launch your online store with our e-commerce development services. We build secure, scalable, and user-friendly e-commerce platforms that drive sales and improve customer experience.',
    icon: <FaShoppingCart className="text-3xl mx-auto mb-2 text-purple-500" />
  },
  {
    name: 'UI/UX Design',
    route: 'ui-ux-design',
    description: 'A visually compelling, consistent, & authoritative design for your websites and apps depicts how UI/UX contributes to customer satisfaction and brand loyalty. Harness the love of millions of user stories.',
    icon: <FaPalette className="text-3xl mx-auto mb-2 text-pink-500" />
  },
  {
    name: 'Mobile Apps Development',
    route: 'mobile-apps-development',
    description: 'Do you want to build a robust mobile app that starts making sense of your user\'s needs, budget, & time? We customize and develop Android, iOS, & desktop apps with our app development services.',
    icon: <FaMobileAlt className="text-3xl mx-auto mb-2 text-cyan-500" />
  },
  {
    name: 'DevOps & Cloud Computing',
    route: 'devops-cloud-computing',
    description: 'With DevOps consulting, achieve high-quality automation faster using GCP, AWS, & Azure. Practice DevOps on multiple servers and realize the full potential of cloud computing more quickly.',
    icon: <FaCloud className="text-gray-500 text-3xl mx-auto mb-2" />
  },
];


export const technologies = [
    { name: 'React', icon: <FaReact className="text-4xl mx-auto mb-2 text-blue-500" /> },
    { name: 'Node.js', icon: <FaNodeJs className="text-4xl mx-auto mb-2 text-green-600" /> },
    { name: 'Tailwind CSS', icon: <SiTailwindcss className="text-4xl mx-auto mb-2 text-cyan-400" /> },
    { name: 'MongoDB', icon: <SiMongodb className="text-4xl mx-auto mb-2 text-green-700" /> },
    { name: 'Express.js', icon: <SiExpress className="text-4xl mx-auto mb-2 text-gray-800" /> },
    { name: 'JavaScript', icon: <FaJs className="text-4xl mx-auto mb-2 text-yellow-500" /> },
    { name: 'HTML5', icon: <FaHtml5 className="text-4xl mx-auto mb-2 text-orange-500" /> },
    { name: 'CSS3', icon: <FaCss3 className="text-4xl mx-auto mb-2 text-blue-400" /> },
    { name: 'Python', icon: <FaPython className="text-4xl mx-auto mb-2 text-blue-600" /> },
    { name: 'Java', icon: <FaJava className="text-4xl mx-auto mb-2 text-red-600" /> },
]

export const industries = [
  {
    icon: <FaGraduationCap className="text-blue-500 text-3xl" />,
    title: 'Finance',
    description: 'Our solutions for the banking and finance sector address a range of technology challenges, from secure online transactions to advanced financial management systems. We help institutions enhance their operational efficiency, reduce fraud, and meet regulatory requirements with our tailored, cutting-edge technology solutions.'
  },
  {
    icon: <FaTruck className="text-orange-500 text-3xl" />,
    title: 'Transportation & Logistics',
    description: 'Enhance your transportation and logistics operations with our technology solutions that streamline management, tracking, and coordination. Our systems improve route planning, real-time tracking, inventory management, and supply chain visibility, leading to increased efficiency, reduced costs, and better customer satisfaction.'
  },
  {
    icon: <FaBuilding className="text-gray-500 text-3xl" />,
    title: 'Real Estate ',
    description: 'Our technology solutions for the real estate and construction industries are designed to innovate and streamline processes. We offer tools for project management, property management, real estate transactions, and construction planning. Our solutions help improve project efficiency, enhance collaboration, and deliver better outcomes for clients and stakeholders.'
  },
  
  {
    icon: <FaShoppingCart className="text-pink-500 text-3xl" />,
    title: 'Retail',
    description: 'Boost your retail and FMCG business with our comprehensive technology solutions that enhance customer experiences, optimize inventory management, and drive sales performance. We offer tools for eCommerce, point-of-sale systems, customer relationship management (CRM), and data analytics, all aimed at increasing efficiency and boosting revenue.'
  },
  
  {
    icon: <FaShoppingBag className="text-teal-500 text-3xl" />,
    title: 'eCommerce & mCommerce',
    description: 'Expand your eCommerce and mCommerce capabilities with our technology solutions that facilitate seamless online and mobile shopping experiences. We offer platforms for online store management, mobile commerce, payment processing, and customer engagement, designed to drive sales and improve the overall shopping experience for your customers.'
  },
  
];

export const values = [
    {
      icon: <FaHandHoldingHeart className="text-red-500 text-4xl" />,
      title: 'Reliability',
      description: 'In the fast-paced digital world, products require both precision and performance. We develop accessible digital solutions that perform seamlessly across diverse platforms, ensuring your business remains agile and responsive.'
    },
    {
      icon: <FaUsers className="text-green-500 text-4xl" />,
      title: 'Collaboration',
      description: 'Effective app development begins with strong collaboration. We break down communication barriers and foster teamwork, celebrating each milestone according to shared goals and timelines.'
    },
    {
      icon: <FaEye className="text-blue-500 text-4xl" />,
      title: 'Transparency',
      description: 'Successful project execution revolves around transparency. Our approach ensures that each phase of mobile and web app development is clear and aligned with your needs, fostering trust and clarity throughout the process.'
    },
    {
      icon: <FaRocket className="text-purple-500 text-4xl" />,
      title: 'Dynamism',
      description: 'Our seasoned professionals excel at developing mobile and web applications from the ground up. Partner with us to tap into their expertise and launch world-class digital products.'
    },
    {
      icon: <FaLightbulb className="text-yellow-500 text-4xl" />,
      title: 'Innovation',
      description: 'We thrive on creativity and innovation. Our team is dedicated to exploring new ideas and technologies to bring fresh perspectives and groundbreaking solutions to your business challenges.'
    },
    {
      icon: <FaCogs className="text-orange-500 text-4xl" />,
      title: 'Efficiency',
      description: 'Efficiency is at the core of our development process. We streamline workflows and leverage the latest technologies to deliver high-quality solutions that save time and resources for your business.'
    },
    {
      icon: <FaChessBoard className="text-indigo-500 text-4xl" />,
      title: 'Strategy Thinking',
      description: 'Analyse the market, competitors, and end-user requirements to determine the most efficient strategy for accomplishing corporate goals. Our strategic approach ensures effective and actionable solutions.'
    },
    {
      icon: <FaDollarSign className="text-green-600 text-4xl" />,
      title: 'Affordable & Quality Product',
      description: 'Experience premium business solutions without breaking the bank – we provide cost-effective, high-quality solutions that deliver exceptional value.'
    }
];
export const serviceData = {
  'custom-software-development': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682310664746-f934119dffd6?q=80&w=2028&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682310916908-3dd53df309b8?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682310918818-6e9a96a3ca2e?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Custom software development tailored to your specific needs and goals, delivering innovative and scalable solutions.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682310922955-ea5e6f791471?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Comprehensive support throughout the software lifecycle, from planning and development to deployment and maintenance.', type: 'right' },
    ],
    cards: [
      { title: 'End-to-End Development', description: 'From initial concept to final product, we handle every stage of the development process.', icon: <FaCode className="text-3xl text-blue-500" /> },
      { title: 'Scalable Solutions', description: 'Our solutions are designed to scale with your business growth and evolving needs.', icon: <FaProjectDiagram className="text-3xl text-green-500" /> },
      { title: 'Expert Team', description: 'Work with experienced professionals who are dedicated to delivering high-quality results.', icon: <FaUserCog className="text-3xl text-red-500" /> },
      { title: 'Ongoing Support', description: 'We offer continuous support and updates to ensure your software remains effective.', icon: <FaDatabase className="text-3xl text-purple-500" /> },
    ],
  },
  'website-designing': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682310597209-306e3bc6c873?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682310595106-ecf4ee316a54?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682310597209-306e3bc6c873?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Designing visually appealing and user-friendly websites that effectively communicate your brand message.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682310595106-ecf4ee316a54?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Responsive and adaptive designs that ensure a seamless user experience across all devices and screen sizes.', type: 'right' },
    ],
    cards: [
      { title: 'Responsive Design', description: 'Creating websites that look great on all devices.', icon: <FaCode className="text-3xl text-blue-500" /> },
      { title: 'User Experience', description: 'Focusing on user-friendly designs and intuitive interfaces.', icon: <FaProjectDiagram className="text-3xl text-green-500" /> },
      { title: 'SEO Friendly', description: 'Designing websites that are optimized for search engines.', icon: <FaSearch className="text-3xl text-yellow-500" /> },
      { title: 'Branding', description: 'Crafting visually appealing designs that align with your brand identity.', icon: <FaPaintBrush className="text-3xl text-pink-500" /> },
    ],
  },
  'web-development': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682299796015-4c2b04dc56aa?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682311158676-568d6938eb92?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682299796015-4c2b04dc56aa?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Developing custom web applications that meet your specific business requirements and enhance user engagement.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682311158676-568d6938eb92?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Ensuring high performance and scalability for your web applications with efficient and effective solutions.', type: 'right' },
    ],
    cards: [
      { title: 'Custom Applications', description: 'Developing applications tailored to your specific needs.', icon: <FaCode className="text-3xl text-blue-500" /> },
      { title: 'Performance Optimization', description: 'Ensuring your web applications run efficiently and smoothly.', icon: <FaTachometerAlt className="text-3xl text-yellow-500" /> },
      { title: 'Integration', description: 'Seamlessly integrating your web applications with existing systems.', icon: <FaPlug className="text-3xl text-orange-500" /> },
      { title: 'Maintenance & Support', description: 'Providing ongoing support to keep your applications up-to-date and functional.', icon: <FaTools className="text-3xl text-gray-500" /> },
    ],
  },
  'it-consulting': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1721312495951-7be5bcc39b4d?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682299257648-a19f5879e226?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1721312495951-7be5bcc39b4d?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Offering strategic IT consulting services to align technology with your business objectives and enhance overall performance.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682299257648-a19f5879e226?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Providing expert guidance on technology adoption, risk management, and IT strategy development.', type: 'right' },
    ],
    cards: [
      { title: 'Strategic Planning', description: 'Providing strategic insights to align IT with your business goals.', icon: <FaChartLine className="text-3xl text-blue-500" /> },
      { title: 'Technology Assessments', description: 'Evaluating and recommending the best technology solutions for your needs.', icon: <FaUserCog className="text-3xl text-red-500" /> },
      { title: 'Risk Management', description: 'Identifying and mitigating potential IT risks to safeguard your business.', icon: <FaShieldAlt className="text-3xl text-gray-500" /> },
      { title: 'IT Strategy Development', description: 'Crafting comprehensive IT strategies to drive your business forward.', icon: <FaProjectDiagram className="text-3xl text-green-500" /> },
    ],
  },
  'software-testing': {
    carouselImages: [
      'https://via.placeholder.com/600x400',
      'https://via.placeholder.com/600x400',
    ],
    sections: [
      { imagePath: 'https://via.placeholder.com/1000x400', content: 'Providing thorough software testing services to ensure your applications meet quality standards and perform reliably.', type: 'left' },
      { imagePath: 'https://via.placeholder.com/1000x400', content: 'Utilizing both automated and manual testing methods to identify and resolve potential issues before deployment.', type: 'right' },
    ],
    cards: [
      { title: 'Automated Testing', description: 'Implementing automated tests to ensure reliable and efficient software.', icon: <FaRobot className="text-3xl text-blue-500" /> },
      { title: 'Manual Testing', description: 'Conducting manual tests to identify issues that automated tests might miss.', icon: <FaUserShield className="text-3xl text-red-500" /> },
      { title: 'Performance Testing', description: 'Assessing the performance of your software under various conditions.', icon: <FaTachometerAlt className="text-3xl text-yellow-500" /> },
      { title: 'Security Testing', description: 'Ensuring your software is secure from vulnerabilities and threats.', icon: <FaLock className="text-3xl text-gray-500" /> },
    ],
  },
  'digital-marketing': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682311154762-16aa43367556?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682270324668-19b639c7502d?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682311154762-16aa43367556?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Offering comprehensive digital marketing services to enhance your online presence and drive customer engagement.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682270324668-19b639c7502d?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Leveraging various digital marketing strategies including SEO, social media, and content marketing to achieve your business goals.', type: 'right' },
    ],
    cards: [
      { title: 'SEO Optimization', description: 'Improving your website’s visibility in search engine results.', icon: <FaSearch className="text-3xl text-yellow-500" /> },
      { title: 'Social Media Marketing', description: 'Leveraging social media platforms to increase your brand’s reach and engagement.', icon: <FaShareAlt className="text-3xl text-blue-500" /> },
      { title: 'Content Marketing', description: 'Creating valuable content to attract and retain customers.', icon: <FaFileAlt className="text-3xl text-green-500" /> },
      { title: 'Email Marketing', description: 'Developing targeted email campaigns to drive conversions.', icon: <FaEnvelope className="text-3xl text-red-500" /> },
    ],
  },
  'search-engine-optimization': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682303144152-3a45445383f8?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682310925148-79b2d439b5ea?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682303144152-3a45445383f8?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Implementing SEO strategies to improve your website’s search engine ranking and attract more organic traffic.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682310925148-79b2d439b5ea?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Utilizing on-page and off-page SEO techniques to enhance your website’s visibility and performance.', type: 'right' },
    ],
    cards: [
      { title: 'Keyword Research', description: 'Identifying relevant keywords to target in your SEO strategy.', icon: <FaSearch className="text-3xl text-yellow-500" /> },
      { title: 'On-Page Optimization', description: 'Optimizing individual web pages to rank higher and earn more relevant traffic.', icon: <FaTachometerAlt className="text-3xl text-blue-500" /> },
      { title: 'Link Building', description: 'Acquiring high-quality backlinks to improve your site’s authority.', icon: <FaShareAlt className="text-3xl text-green-500" /> },
      { title: 'Analytics & Reporting', description: 'Tracking and analyzing SEO performance to refine strategies and achieve better results.', icon: <FaChartLine className="text-3xl text-purple-500" /> },
    ],
  },
  'mobile-apps-development': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682309436489-21103d3f90d4?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682309436489-21103d3f90d4?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682309420112-0f15593f4273?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Developing innovative mobile applications that offer a seamless user experience across various devices.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682309289526-a70f4b0967a9?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Utilizing the latest technologies to create high-performance and user-friendly mobile apps.', type: 'right' },
    ],
    cards: [
      { title: 'iOS & Android Apps', description: 'Creating mobile applications for both iOS and Android platforms.', icon: <FaMobileAlt className="text-3xl text-blue-500" /> },
      { title: 'User Experience Design', description: 'Designing intuitive and engaging user interfaces for mobile apps.', icon: <FaUserAlt className="text-3xl text-red-500" /> },
      { title: 'App Maintenance', description: 'Providing ongoing maintenance and updates to ensure app functionality.', icon: <FaTools className="text-3xl text-green-500" /> },
      { title: 'Performance Optimization', description: 'Optimizing app performance to deliver a smooth user experience.', icon: <FaTachometerAlt className="text-3xl text-yellow-500" /> },
    ],
  },
  'ui-ux-design': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1711987521929-4c80ae81998f?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1711987521929-4c80ae81998f?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1719990020642-83783c20f742?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Designing intuitive and engaging user interfaces that enhance user experience and drive user satisfaction.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1719990020640-4440ecfabd17?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Creating user-centered designs with a focus on usability, accessibility, and aesthetics.', type: 'right' },
    ],
    cards: [
      { title: 'User Research', description: 'Conducting research to understand user needs and behaviors.', icon: <FaUsers className="text-3xl text-blue-500" /> },
      { title: 'Wireframing & Prototyping', description: 'Developing wireframes and prototypes to visualize and test design concepts.', icon: <FaFileAlt className="text-3xl text-green-500" /> },
      { title: 'UI Design', description: 'Designing visually appealing user interfaces that align with brand identity and user needs.', icon: <FaPaintBrush className="text-3xl text-orange-500" /> },
      { title: 'UX Testing', description: 'Conducting usability testing to ensure designs meet user expectations and enhance overall experience.', icon: <FaRocket className="text-3xl text-red-500" /> },
    ],
  },
  'devops-cloud-computing': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1712873279565-feb54b2c4568?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1712873279565-feb54b2c4568?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1683141305195-6cdfd5214b49?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Streamlining your development and deployment processes with DevOps practices and scalable cloud solutions.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1682301032918-40f46892886a?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Optimizing infrastructure, enhancing performance, and ensuring high availability with our DevOps and cloud computing services.', type: 'right' },
    ],
    cards: [
      { title: 'Continuous Integration & Delivery (CI/CD)', description: 'Automating development and deployment pipelines to accelerate delivery and ensure quality.', icon: <FaSyncAlt className="text-3xl text-blue-500" /> },
      { title: 'Infrastructure as Code (IaC)', description: 'Managing and provisioning infrastructure through code to improve consistency and scalability.', icon: <FaCode className="text-3xl text-green-500" /> },
      { title: 'Cloud Migration', description: 'Migrating applications and data to the cloud to enhance scalability, flexibility, and performance.', icon: <FaCloudUploadAlt className="text-3xl text-gray-500" /> },
      { title: 'Performance Optimization', description: 'Enhancing the performance and efficiency of your cloud infrastructure and DevOps practices.', icon: <FaTachometerAlt className="text-3xl text-red-500" /> },
    ],
  },
  'ecommerce-development': {
    carouselImages: [
      'https://plus.unsplash.com/premium_vector-1682310925148-79b2d439b5ea?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      'https://plus.unsplash.com/premium_vector-1682309441185-bd865b4d207e?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ],
    sections: [
      { imagePath: 'https://plus.unsplash.com/premium_vector-1719829071191-2d1dcc862ebe?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Developing tailored eCommerce solutions to boost online sales and enhance customer experiences.', type: 'left' },
      { imagePath: 'https://plus.unsplash.com/premium_vector-1719829071224-9d289d2ab992?q=80&w=1800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', content: 'Implementing effective strategies and technologies to streamline your online store operations.', type: 'right' },
    ],
    cards: [
      { title: 'Custom Store Design', description: 'Creating a unique and engaging online store experience.', icon: <FaPaintBrush className="text-3xl text-blue-500" /> },
      { title: 'Payment Integration', description: 'Implementing secure and convenient payment solutions.', icon: <FaCreditCard className="text-3xl text-green-500" /> },
      { title: 'Inventory Management', description: 'Streamlining inventory management for efficient operations.', icon: <FaWarehouse className="text-3xl text-orange-500" /> },
      { title: 'Customer Analytics', description: 'Providing insights into customer behavior to optimize your sales strategy.', icon: <FaChartLine className="text-3xl text-red-500" /> },
    ],
  },
};

